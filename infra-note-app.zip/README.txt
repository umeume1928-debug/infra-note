# インフラノート（ITインフラ学習Webアプリ）

## 入っている機能
- DNS / キャッシュ / DNS問い合わせ経路 / ポート番号の初期用語
- 用語の追加・編集・検索・削除
- 4択クイズ、全体出題、間違えた用語の復習
- 正解率、学習日、連続学習日数、用語定着度
- JSON形式のバックアップ・復元
- PWA用manifest・service worker・アイコン

## iPhoneに導入するには
このZIPを展開しただけでは、ホーム画面追加やオフライン機能が完全には動きません。HTTPSで公開してください。

### GitHub Pagesで公開する手順
1. GitHubにログインし、新しいRepositoryを作成（Publicが簡単。例: infra-note）。
2. ZIPを展開し、index.html / manifest.json / sw.js / icon-192.png / icon-512.png をリポジトリ直下へアップロードしてCommit。
3. Repositoryの Settings → Pages → Build and deployment で、Deploy from a branch を選択。
4. Branchを main、folderを /(root) にして Save。
5. 表示された `https://ユーザー名.github.io/リポジトリ名/` をiPhoneのSafariで開く。
6. Safariの共有ボタン →「ホーム画面に追加」。表示される場合は「Webアプリとして開く」を有効にして追加。
7. ホーム画面の「インフラノート」アイコンから起動。

## 注意
- データは端末のブラウザ内に保存します。別端末との自動同期はありません。
- SafariのWebサイトデータを消すと記録が消えることがあります。進捗画面から定期的にバックアップを保存してください。
- iOSのロック画面ウィジェットは、このWebアプリだけでは作れません。
- このプロトタイプは初期データのクイズが中心です。追加した用語はメモとして保存できますが、クイズ問題は現状、初期登録分のみです。
